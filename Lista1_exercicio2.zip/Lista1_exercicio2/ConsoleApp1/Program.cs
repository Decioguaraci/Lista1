﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double l1;
            double area;
            Console.Write("Digite o valor da aresta do quadrado: ");
            l1=double.Parse(Console.ReadLine());
            area=l1 * l1;
            Console.WriteLine("A área do quadrado, com aresta de {0}", area);



        }
    }
}
