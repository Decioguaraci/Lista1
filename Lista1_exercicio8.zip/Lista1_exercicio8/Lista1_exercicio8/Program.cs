﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_exercicio8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;
            Console.WriteLine("Exercício 8 da lista 1");
            Console.WriteLine("");
            Console.Write("Digite o valor em graus Celsius: ");
            valor=double.Parse(Console.ReadLine());
            resultado = (valor * 1.8) + 32;
            Console.WriteLine("Resultado em graus Fahrenheit: {0}",resultado);

        }
    }
}
