﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_exercicio4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nbase;
            double altura;
            double resultado;
            Console.WriteLine("Exercício número 4 da lista 1");
            Console.WriteLine("");
            Console.Write("Digite o valor da base: ");
            nbase=double.Parse(Console.ReadLine());
            Console.Write("Digite o valor da altura: ");
            altura=double.Parse(Console.ReadLine());
            resultado = (nbase * altura) / 2;
            Console.WriteLine("Resultado: {0}", resultado);


        }
    }
}
