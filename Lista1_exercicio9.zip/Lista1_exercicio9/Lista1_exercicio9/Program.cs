﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_exercicio9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;
            Console.WriteLine("Exercício 9 da lista 1");
            Console.WriteLine("");
            Console.Write("Digite o diâmetro do círculo: ");
            valor=double.Parse(Console.ReadLine());
            resultado = Math.PI * Math.Pow((valor / 2), 2);
            Console.WriteLine("Resultado:{0}", resultado);

        }
    }
}
