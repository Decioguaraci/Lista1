﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_exercicio3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diagonal;
            double lado;
            double resultado;
            Console.WriteLine("Exercicio 3 da lista 1");
            Console.WriteLine(" ");
            Console.Write("Digite o valor da diagonal: ");
            diagonal=double.Parse(Console.ReadLine());
            lado = diagonal / Math.Sqrt(2);
            resultado=Math.Pow(lado, 2);
            Console.WriteLine("resultado: {0}", resultado);
           


        }
    }
}
