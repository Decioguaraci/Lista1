﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_exercicio12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valorp1;
            double valorp2;
            double valorp3;
            double valorp4;
            double valorp5;
            double pagamento;
            double troco;
            Console.WriteLine("Exercício 12 da lista 1");
            Console.WriteLine("");
            Console.Write("Digite o valor do primeiro produto: R$");
            valorp1=double.Parse(Console.ReadLine());
            Console.Write("Digite o valor do segundo produto: R$");
            valorp2=double.Parse(Console.ReadLine());
            Console.Write("Digite o valor do terceiro produto: R$");
            valorp3=double.Parse(Console.ReadLine());
            Console.Write("Digite o valor do quarto produto");
            valorp4=double.Parse(Console.ReadLine());
            Console.Write("Digite o valor do quinto produto: ");
            valorp5=double.Parse(Console.ReadLine());
            Console.WriteLine("");
            Console.Write("Digite o valor do pagamento: R$");
            pagamento=double.Parse(Console.ReadLine());
            double.Parse(Console.ReadLine());
            troco=pagamento-(valorp1+valorp2+valorp2+valorp3+valorp4+valorp5);
            Console.WriteLine("Troco: {0}", troco.ToString("C"));
                
        }
    }
}
