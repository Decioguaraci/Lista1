﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_exercicio10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valordolar;
            double valorcotacao;
            double resultado;
            Console.WriteLine("Exercício 10 da lista 1");
            Console.WriteLine("");
            Console.Write("Digite o valor da cotação do Dólar: R$ ");
            valorcotacao=double.Parse(Console.ReadLine());
            Console.Write("Digite o valor em dólares: US$ ");
            valordolar=double.Parse(Console.ReadLine());
            resultado = valordolar * valorcotacao;
            Console.WriteLine("Resultado em Reais: {0}", resultado.ToString("C"));
        }
    }
}
