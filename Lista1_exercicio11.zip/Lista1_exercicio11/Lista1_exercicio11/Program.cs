﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_exercicio11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nbase;
            double expoente;
            double resultado;
            Console.WriteLine("Exercício 11 da lista 1");
            Console.WriteLine("");
            Console.Write("Digite o valor da Base: ");
            nbase=double.Parse(Console.ReadLine());
            Console.Write("Dígite o valor do expoente: ");
            expoente=double.Parse(Console.ReadLine());  
            resultado=Math.Pow(nbase,expoente);
            Console.WriteLine("Resultado: {0}", resultado);
        }
    }
}
